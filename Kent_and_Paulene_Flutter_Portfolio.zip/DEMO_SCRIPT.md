# 🎥 Laboratory Video Demonstration Script
### CS 416 - Mobile Computing 2 | Master Portfolio App
**Presenter(s)**: Kent & Paulene  
**Subject**: Laboratory Activities Compilation & Network Resiliency

---

## 🎬 Presentation Timeline & Script

---

### ⏱️ Section 1: Introduction (0:00 - 0:30)

**[Action on Screen]**: Open the app on your Android phone (**CPH2211**). Show the **Master Portfolio Hub** home screen.

**🗣️ Spoken Script**:
> "Good day! Today we are presenting our Master Compilation App for CS 416: Mobile Computing 2, developed by Kent and Paulene.
> 
> This Flutter application serves as our master hub for all laboratory activities. It is built following declarative UI principles, responsive layout architecture, global Provider state management, and real-time network stream listening."

---

### ⏱️ Section 2: Responsive Layout Architecture (0:30 - 1:00)

**[Action on Screen]**: 
1. Scroll up and down on the Home Dashboard.
2. Rotate the phone to **Landscape Mode** (or resize the app window).
3. Point out how the GridView grid count smoothly adjusts from 1 column (portrait) to 2 or 3 columns (landscape) with zero yellow-and-black pixel overflow banners.

**🗣️ Spoken Script**:
> "First, let's look at the **Responsive Layout Architecture**. 
> 
> We used Flutter's `LayoutBuilder`, `GridView.count`, and native layout flex widgets like `Expanded` and `Flexible`. Notice how all text and elements automatically adjust dynamically without any fixed pixel constraints or screen overflow errors when rotating the device."

---

### ⏱️ Section 3: Global State Management with Provider (1:00 - 1:45)

**[Action on Screen]**: 
1. Tap the **Sun/Moon icon** in the AppBar to switch between **Light Mode** and **Dark Mode**.
2. Tap the **Settings icon** in the AppBar.
3. Change the user profile name to *"Kent Jerico & Paulene"* and save.
4. Navigate back to the Home Dashboard to show the welcome banner live update.

**🗣️ Spoken Script**:
> "Next is **Global State Management**. 
> 
> We implemented the `Provider` pattern using `AppStateProvider`. When we toggle the dark mode theme button in the top app bar, the theme instantly changes app-wide. 
> 
> Furthermore, when we edit our student profile details on the Settings screen, the changes immediately propagate live across the Home Dashboard hero header and activity counters."

---

### ⏱️ Section 4: Real-Time Network Handover & Stream Listener (1:45 - 2:30)

**[Action on Screen]**: 
1. Tap the **Lab 4: Network Monitor** card on the Home Dashboard.
2. Show the top **Connection Status Banner** displaying **"Connected via Wi-Fi"** (Teal banner).
3. Swipe down your Android quick settings tray and **turn off Wi-Fi** (forcing a switch to Cellular Mobile Data).
4. Show the UI dynamically updating in real-time to **"Connected via Cellular"** (Purple banner).
5. Highlight the **Stream Event Logs** terminal at the bottom showing the exact handover event: `WIFI -> CELLULAR`.

**🗣️ Spoken Script**:
> "Now, let's demonstrate **Lab 4: Network Monitor and Stream Listener**.
> 
> Using the `connectivity_plus` package, our app subscribes to real-time network state change streams. Currently, the status banner shows we are connected via **Wi-Fi**.
> 
> Watch what happens when I pull down the quick settings tray and turn off Wi-Fi: the app instantly detects the network IP handover and dynamically updates the UI to **'Connected via Cellular'** in real-time. Notice how the Stream Event Log records the transition."

---

### ⏱️ Section 5: Request Queuing & Graceful Auto-Recovery (2:30 - 3:30)

**[Action on Screen]**: 
1. Tap **"Fetch Heavy Dataset (5MB)"** to start a long-running transfer (progress bar starts moving).
2. While the progress bar is running, toggle your phone to **Airplane Mode** (or switch on the **"Simulate Connection Drop"** switch on screen).
3. Show the app catching the error safely without crashing! Point out the status pill changing to **`FAILED (RETRYING)`** or **`QUEUED`**.
4. Now, turn **Wi-Fi / Cellular back ON** (or turn off the simulation switch).
5. Watch the stream callback automatically detect network restoration, flush the queue, and resume the download to **`COMPLETED`** status with progress hitting 100%!

**🗣️ Spoken Script**:
> "Finally, let's demonstrate our **Request Queuing System and Graceful Recovery**.
> 
> I will trigger a heavy 5MB dataset download. If the connection drops during this long-running request—for example, by toggling off Wi-Fi or activating Airplane Mode—the app catches the network error gracefully instead of crashing. 
> 
> As you can see, the payload is safely added to our **Request Queue System** with status `QUEUED` or `FAILED (RETRYING)`.
> 
> As soon as a stable Wi-Fi or Cellular connection is re-established, the stream listener callback fires automatically. It recovers the queued payload and resumes processing until it reaches 100% `COMPLETED`. No data is lost, and user experience remains smooth!"

---

### ⏱️ Section 6: Conclusion (3:30 - 3:45)

**[Action on Screen]**: Return to the Home Dashboard showing all 4 completed modules.

**🗣️ Spoken Script**:
> "In conclusion, our app demonstrates robust widget architecture, responsive design, global state synchronization, and enterprise-grade network stream resiliency. 
> 
> Thank you for watching!"

---

### 💡 Quick Presentation Tips:
* **Screen Recorder**: Use Android built-in Screen Recorder (or Scrcpy on PC).
* **Network Testing**: You can test network drops using either your phone's real **Wi-Fi / Airplane Mode toggles** OR the on-screen **Simulate Connection Drop switch**!
