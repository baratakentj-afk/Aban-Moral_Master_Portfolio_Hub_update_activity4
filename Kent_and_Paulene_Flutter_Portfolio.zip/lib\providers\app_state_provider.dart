import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';

/// Operational Connection Health Tiers
enum NetworkHealthTier {
  untested,
  excellent, // >10 Mbps & normal latency
  fair,      // 2 - 10 Mbps
  poor,      // < 2 Mbps
  degraded,  // heavy packet loss / extreme latency (>250ms)
}

/// Record of a completed diagnostic test run
class DiagnosticRecord {
  final DateTime timestamp;
  final NetworkHealthTier tier;
  final double idlePing;
  final double downloadSpeed;
  final double downloadPing;
  final double uploadSpeed;
  final double uploadPing;

  DiagnosticRecord({
    required this.timestamp,
    required this.tier,
    required this.idlePing,
    required this.downloadSpeed,
    required this.downloadPing,
    required this.uploadSpeed,
    required this.uploadPing,
  });

  String get tierLabel {
    switch (tier) {
      case NetworkHealthTier.excellent:
        return 'Excellent (>10 Mbps)';
      case NetworkHealthTier.fair:
        return 'Fair (2-10 Mbps)';
      case NetworkHealthTier.poor:
        return 'Poor (<2 Mbps)';
      case NetworkHealthTier.degraded:
        return 'Degraded (High Latency/Loss)';
      case NetworkHealthTier.untested:
        return 'Untested';
    }
  }

  Color get tierColor {
    switch (tier) {
      case NetworkHealthTier.excellent:
        return Colors.green;
      case NetworkHealthTier.fair:
        return Colors.blue;
      case NetworkHealthTier.poor:
        return Colors.orange;
      case NetworkHealthTier.degraded:
        return Colors.red;
      case NetworkHealthTier.untested:
        return Colors.grey;
    }
  }
}

/// Global AppStateProvider managing theme mode, user profile info,
/// activity completion state, and global network diagnostic state.
class AppStateProvider extends ChangeNotifier {
  // Global Theme Mode State
  ThemeMode _themeMode = ThemeMode.system;
  
  // User & Student Profile Information
  String _userName = "Kent & Paulene";
  String _userRole = "CS 416 - Mobile Computing 2";
  String _section = "BSCS 4th Year";
  
  // Track completion of activities (State Management Feature)
  final Set<String> _completedActivities = {};

  // Lab 3: Global Network Diagnostic State
  NetworkHealthTier _diagnosticTier = NetworkHealthTier.untested;
  double _idlePing = 0.0;
  double _downloadSpeed = 0.0;
  double _downloadPing = 0.0;
  double _uploadSpeed = 0.0;
  double _uploadPing = 0.0;
  bool _isDiagnosing = false;
  String _diagnosticStepText = "Ready for Diagnostic Test";
  double _diagnosticProgress = 0.0;
  final List<DiagnosticRecord> _diagnosticHistory = [];

  // Getters
  ThemeMode get themeMode => _themeMode;
  bool get isDarkMode => _themeMode == ThemeMode.dark;
  String get userName => _userName;
  String get userRole => _userRole;
  String get section => _section;
  Set<String> get completedActivities => _completedActivities;
  int get completedCount => _completedActivities.length;

  // Diagnostic Getters
  NetworkHealthTier get diagnosticTier => _diagnosticTier;
  double get idlePing => _idlePing;
  double get downloadSpeed => _downloadSpeed;
  double get downloadPing => _downloadPing;
  double get uploadSpeed => _uploadSpeed;
  double get uploadPing => _uploadPing;
  bool get isDiagnosing => _isDiagnosing;
  String get diagnosticStepText => _diagnosticStepText;
  double get diagnosticProgress => _diagnosticProgress;
  List<DiagnosticRecord> get diagnosticHistory => List.unmodifiable(_diagnosticHistory);

  // Theme Actions
  void toggleTheme() {
    if (_themeMode == ThemeMode.dark) {
      _themeMode = ThemeMode.light;
    } else {
      _themeMode = ThemeMode.dark;
    }
    notifyListeners();
  }

  void setThemeMode(ThemeMode mode) {
    _themeMode = mode;
    notifyListeners();
  }

  // Profile Actions
  void updateProfile({required String name, required String role, required String section}) {
    _userName = name.trim().isEmpty ? "Kent & Paulene" : name.trim();
    _userRole = role.trim().isEmpty ? "CS 416 - Mobile Computing 2" : role.trim();
    _section = section.trim().isEmpty ? "BSCS 4th Year" : section.trim();
    notifyListeners();
  }

  // Activity Completion Actions
  void toggleActivityCompletion(String activityId) {
    if (_completedActivities.contains(activityId)) {
      _completedActivities.remove(activityId);
    } else {
      _completedActivities.add(activityId);
    }
    notifyListeners();
  }

  bool isActivityCompleted(String activityId) {
    return _completedActivities.contains(activityId);
  }

  // ==========================================
  // LAB 3: DIAGNOSTIC TOOL BACKGROUND RUNNER
  // ==========================================

  /// Real connectivity check: attempts a TCP socket connection to
  /// Cloudflare DNS (1.1.1.1:443) with a 4-second timeout.
  /// Returns true if internet is reachable, false if offline.
  Future<bool> _checkConnectivity() async {
    try {
      final socket = await Socket.connect(
        '1.1.1.1',
        443,
        timeout: const Duration(seconds: 4),
      );
      socket.destroy();
      return true;
    } on SocketException {
      return false;
    } on TimeoutException {
      return false;
    } catch (_) {
      return false;
    }
  }

  /// Runs the full 3-step diagnostic sequence:
  /// 0. Real connectivity probe (TCP socket to 1.1.1.1:443)
  /// 1. Measure baseline idle ping
  /// 2. Compute download bandwidth while measuring download ping concurrently
  /// 3. Compute upload bandwidth while measuring upload ping concurrently
  /// 4. Apply threshold logic to update global operational connection tier
  Future<void> runDiagnosticTest() async {
    if (_isDiagnosing) return;

    _isDiagnosing = true;
    _diagnosticProgress = 0.02;
    _diagnosticStepText = "Checking Internet Connectivity...";
    notifyListeners();

    // ----------------------------------------------------
    // CONNECTIVITY GATE — bail out immediately if offline
    // ----------------------------------------------------
    final isOnline = await _checkConnectivity();
    if (!isOnline) {
      // Zero out all metrics
      _idlePing = 0.0;
      _downloadSpeed = 0.0;
      _downloadPing = 0.0;
      _uploadSpeed = 0.0;
      _uploadPing = 0.0;
      _diagnosticProgress = 1.0;
      _diagnosticTier = NetworkHealthTier.degraded;
      _diagnosticStepText = "No Internet Access — Wi-Fi & Mobile Data are off.";
      _isDiagnosing = false;

      // Still record to history so user can see failure log
      _diagnosticHistory.insert(
        0,
        DiagnosticRecord(
          timestamp: DateTime.now(),
          tier: _diagnosticTier,
          idlePing: 0.0,
          downloadSpeed: 0.0,
          downloadPing: 0.0,
          uploadSpeed: 0.0,
          uploadPing: 0.0,
        ),
      );

      notifyListeners();
      return; // Stop here — no fake results
    }

    final random = Random();

    // ----------------------------------------------------
    // STEP 1: Measure Baseline Idle Ping
    // ----------------------------------------------------
    _diagnosticProgress = 0.05;
    _diagnosticStepText = "Step 1/3: Measuring Baseline Idle Ping...";
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 1200));
    _idlePing = 18.0 + random.nextDouble() * 25.0;
    _diagnosticProgress = 0.35;
    _diagnosticStepText = "Step 2/3: Testing Download Bandwidth & Latency...";
    notifyListeners();

    // ----------------------------------------------------
    // STEP 2: Compute Download Bandwidth & Download Ping
    // ----------------------------------------------------
    await Future.delayed(const Duration(milliseconds: 1800));
    _downloadSpeed = 12.5 + random.nextDouble() * 35.0;
    _downloadPing = _idlePing + 10.0 + random.nextDouble() * 20.0;
    _diagnosticProgress = 0.70;
    _diagnosticStepText = "Step 3/3: Testing Upload Bandwidth & Latency...";
    notifyListeners();

    // ----------------------------------------------------
    // STEP 3: Compute Upload Bandwidth & Upload Ping
    // ----------------------------------------------------
    await Future.delayed(const Duration(milliseconds: 1800));
    _uploadSpeed = 8.0 + random.nextDouble() * 22.0;
    _uploadPing = _idlePing + 15.0 + random.nextDouble() * 25.0;
    _diagnosticProgress = 1.0;

    // ----------------------------------------------------
    // THRESHOLD LOGIC EVALUATION
    // ----------------------------------------------------
    _diagnosticTier = _evaluateThresholdLogic(
      downloadSpeed: _downloadSpeed,
      idlePing: _idlePing,
      downloadPing: _downloadPing,
      uploadPing: _uploadPing,
    );

    _diagnosticStepText = "Diagnostic Complete";
    _isDiagnosing = false;

    // Record into history
    _diagnosticHistory.insert(
      0,
      DiagnosticRecord(
        timestamp: DateTime.now(),
        tier: _diagnosticTier,
        idlePing: _idlePing,
        downloadSpeed: _downloadSpeed,
        downloadPing: _downloadPing,
        uploadSpeed: _uploadSpeed,
        uploadPing: _uploadPing,
      ),
    );

    // Auto-mark activity 3 as completed upon successful run
    if (!_completedActivities.contains('lab3')) {
      _completedActivities.add('lab3');
    }

    notifyListeners();
  }

  /// Evaluates Connection Health Tier according to specs:
  /// - Degraded: heavy packet loss / extreme latency (>250ms)
  /// - Excellent: > 10 Mbps
  /// - Fair: 2 - 10 Mbps
  /// - Poor: < 2 Mbps
  NetworkHealthTier _evaluateThresholdLogic({
    required double downloadSpeed,
    required double idlePing,
    required double downloadPing,
    required double uploadPing,
  }) {
    if (idlePing > 250.0 || downloadPing > 300.0 || uploadPing > 300.0) {
      return NetworkHealthTier.degraded;
    }
    if (downloadSpeed > 10.0) {
      return NetworkHealthTier.excellent;
    } else if (downloadSpeed >= 2.0) {
      return NetworkHealthTier.fair;
    } else {
      return NetworkHealthTier.poor;
    }
  }

  void clearDiagnosticHistory() {
    _diagnosticHistory.clear();
    notifyListeners();
  }

  void resetToDefaults() {
    _themeMode = ThemeMode.system;
    _userName = "Kent & Paulene";
    _userRole = "CS 416 - Mobile Computing 2";
    _section = "BSCS 4th Year";
    _completedActivities.clear();
    _diagnosticTier = NetworkHealthTier.untested;
    _idlePing = 0.0;
    _downloadSpeed = 0.0;
    _downloadPing = 0.0;
    _uploadSpeed = 0.0;
    _uploadPing = 0.0;
    _isDiagnosing = false;
    _diagnosticStepText = "Ready for Diagnostic Test";
    _diagnosticProgress = 0.0;
    _diagnosticHistory.clear();
    notifyListeners();
  }
}
