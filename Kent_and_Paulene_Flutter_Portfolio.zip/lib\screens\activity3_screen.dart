import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state_provider.dart';

/// Lab 3: Network Diagnostic Dashboard Screen
/// Integrates a 3-step diagnostic test tool (Idle Ping -> Download Bandwidth + Ping -> Upload Bandwidth + Ping),
/// applies threshold logic for connection operational tiers, and broadcasts results via Provider.
class Activity3Screen extends StatelessWidget {
  const Activity3Screen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final appState = Provider.of<AppStateProvider>(context);
    final isCompleted = appState.isActivityCompleted('lab3');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Lab 3: Network Diagnostic'),
        actions: [
          IconButton(
            icon: Icon(
              isCompleted ? Icons.check_circle : Icons.check_circle_outline,
              color: isCompleted ? Colors.green : null,
            ),
            tooltip: isCompleted ? 'Completed' : 'Mark as Complete',
            onPressed: () {
              appState.toggleActivityCompletion('lab3');
            },
          ),
          if (appState.diagnosticHistory.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_outline_rounded),
              tooltip: 'Clear Diagnostic Logs',
              onPressed: () {
                appState.clearDiagnosticHistory();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Diagnostic History Cleared'),
                    duration: Duration(seconds: 1),
                  ),
                );
              },
            ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. Connection Health Tier Status Banner
              _buildTierHeaderBanner(context, appState),

              const SizedBox(height: 20),

              // 2. Interactive Diagnostic Runner Card
              _buildRunnerControlCard(context, appState),

              const SizedBox(height: 24),

              // Section Title
              Text(
                'Diagnostic Metrics Breakdown',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),

              // 3. Three-Step Metrics Grid / Cards
              _buildMetricsRow(context, appState),

              const SizedBox(height: 24),

              // 4. Threshold Logic Reference Legend
              _buildThresholdLegendCard(context),

              const SizedBox(height: 24),

              // 5. Diagnostic Test History Log
              if (appState.diagnosticHistory.isNotEmpty) ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Diagnostic History (${appState.diagnosticHistory.length})',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    TextButton.icon(
                      onPressed: () => appState.clearDiagnosticHistory(),
                      icon: const Icon(Icons.cleaning_services_rounded, size: 16),
                      label: const Text('Clear'),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                _buildHistoryList(context, appState),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTierHeaderBanner(BuildContext context, AppStateProvider appState) {
    final tier = appState.diagnosticTier;
    final color = _getTierColor(tier);
    final label = _getTierTitle(tier);
    final desc = _getTierDescription(tier);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20.0),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withValues(alpha: 0.85), color],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.3),
            blurRadius: 14,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.2),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  _getTierIcon(tier),
                  color: Colors.white,
                  size: 28,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Global Connection Tier',
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      label,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            desc,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.9),
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRunnerControlCard(BuildContext context, AppStateProvider appState) {
    final theme = Theme.of(context);

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.speed_rounded,
                      color: theme.colorScheme.primary,
                      size: 24,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'Diagnostic Engine',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                if (appState.isDiagnosing)
                  const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2.5),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              appState.diagnosticStepText,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: appState.isDiagnosing
                    ? theme.colorScheme.primary
                    : theme.textTheme.bodyMedium?.color,
              ),
            ),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: appState.diagnosticProgress > 0 ? appState.diagnosticProgress : null,
                minHeight: 6,
                backgroundColor: theme.colorScheme.surfaceContainerHighest,
                valueColor: AlwaysStoppedAnimation<Color>(
                  appState.isDiagnosing ? Colors.deepPurple : Colors.grey,
                ),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: appState.isDiagnosing
                    ? null
                    : () => appState.runDiagnosticTest(),
                icon: Icon(
                  appState.isDiagnosing ? Icons.hourglass_top_rounded : Icons.play_arrow_rounded,
                ),
                label: Text(
                  appState.isDiagnosing ? 'Running Diagnostics...' : 'Start Full Diagnostic Test',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  backgroundColor: Colors.deepPurple,
                  foregroundColor: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMetricsRow(BuildContext context, AppStateProvider appState) {
    return Column(
      children: [
        // Metric 1: Idle Ping
        _buildMetricTile(
          context: context,
          stepNum: '1',
          title: 'Idle Ping Baseline',
          subtitle: 'Latency measured without load',
          mainValue: appState.idlePing > 0
              ? '${appState.idlePing.toStringAsFixed(1)} ms'
              : '---',
          subValue: 'Base Latency',
          icon: Icons.network_ping_rounded,
          accentColor: Colors.teal,
        ),
        const SizedBox(height: 12),

        // Metric 2: Download Bandwidth & Latency
        _buildMetricTile(
          context: context,
          stepNum: '2',
          title: 'Download Bandwidth',
          subtitle: 'Concurrent download speed & latency',
          mainValue: appState.downloadSpeed > 0
              ? '${appState.downloadSpeed.toStringAsFixed(2)} Mbps'
              : '---',
          subValue: appState.downloadPing > 0
              ? 'Ping: ${appState.downloadPing.toStringAsFixed(1)} ms'
              : 'Ping: ---',
          icon: Icons.download_rounded,
          accentColor: Colors.blueAccent,
        ),
        const SizedBox(height: 12),

        // Metric 3: Upload Bandwidth & Latency
        _buildMetricTile(
          context: context,
          stepNum: '3',
          title: 'Upload Bandwidth',
          subtitle: 'Concurrent upload speed & latency',
          mainValue: appState.uploadSpeed > 0
              ? '${appState.uploadSpeed.toStringAsFixed(2)} Mbps'
              : '---',
          subValue: appState.uploadPing > 0
              ? 'Ping: ${appState.uploadPing.toStringAsFixed(1)} ms'
              : 'Ping: ---',
          icon: Icons.upload_rounded,
          accentColor: Colors.orange,
        ),
      ],
    );
  }

  Widget _buildMetricTile({
    required BuildContext context,
    required String stepNum,
    required String title,
    required String subtitle,
    required String mainValue,
    required String subValue,
    required IconData icon,
    required Color accentColor,
  }) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outlineVariant.withValues(alpha: 0.5),
        ),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: accentColor.withValues(alpha: 0.15),
            child: Text(
              stepNum,
              style: TextStyle(
                color: accentColor,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: theme.textTheme.bodySmall?.color,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                mainValue,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: accentColor,
                ),
              ),
              Text(
                subValue,
                style: const TextStyle(
                  fontSize: 11,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildThresholdLegendCard(BuildContext context) {
    return Card(
      elevation: 0,
      color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.info_outline_rounded, size: 18),
                SizedBox(width: 8),
                Text(
                  'Threshold Logic Classification Tiers',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                ),
              ],
            ),
            const SizedBox(height: 10),
            _buildLegendItem(Colors.green, 'Excellent', '> 10 Mbps (Low latency)'),
            _buildLegendItem(Colors.blue, 'Fair', '2 Mbps – 10 Mbps'),
            _buildLegendItem(Colors.orange, 'Poor', '< 2 Mbps'),
            _buildLegendItem(Colors.red, 'Degraded', 'Heavy packet loss / Extreme latency (>250ms)'),
          ],
        ),
      ),
    );
  }

  Widget _buildLegendItem(Color color, String name, String range) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3.0),
      child: Row(
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 8),
          Text(
            '$name: ',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: color),
          ),
          Text(
            range,
            style: const TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryList(BuildContext context, AppStateProvider appState) {
    return ListView.builder(
      itemCount: appState.diagnosticHistory.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemBuilder: (context, index) {
        final record = appState.diagnosticHistory[index];
        final formattedTime =
            '${record.timestamp.hour.toString().padLeft(2, '0')}:${record.timestamp.minute.toString().padLeft(2, '0')}:${record.timestamp.second.toString().padLeft(2, '0')}';

        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ListTile(
            dense: true,
            leading: CircleAvatar(
              radius: 14,
              backgroundColor: record.tierColor.withValues(alpha: 0.2),
              child: Icon(_getTierIcon(record.tier), size: 16, color: record.tierColor),
            ),
            title: Text(
              record.tierLabel,
              style: TextStyle(fontWeight: FontWeight.bold, color: record.tierColor),
            ),
            subtitle: Text(
              'Down: ${record.downloadSpeed.toStringAsFixed(1)} Mbps | Up: ${record.uploadSpeed.toStringAsFixed(1)} Mbps | Idle: ${record.idlePing.toStringAsFixed(0)}ms',
              style: const TextStyle(fontSize: 11),
            ),
            trailing: Text(
              formattedTime,
              style: const TextStyle(fontSize: 11, color: Colors.grey),
            ),
          ),
        );
      },
    );
  }

  Color _getTierColor(NetworkHealthTier tier) {
    switch (tier) {
      case NetworkHealthTier.excellent:
        return Colors.green;
      case NetworkHealthTier.fair:
        return Colors.blue;
      case NetworkHealthTier.poor:
        return Colors.orange;
      case NetworkHealthTier.degraded:
        return Colors.red;
      case NetworkHealthTier.untested:
        return Colors.deepPurple;
    }
  }

  String _getTierTitle(NetworkHealthTier tier) {
    switch (tier) {
      case NetworkHealthTier.excellent:
        return 'Excellent Connection';
      case NetworkHealthTier.fair:
        return 'Fair Connection';
      case NetworkHealthTier.poor:
        return 'Poor Connection';
      case NetworkHealthTier.degraded:
        return 'Degraded Connection';
      case NetworkHealthTier.untested:
        return 'Untested Connection';
    }
  }

  String _getTierDescription(NetworkHealthTier tier) {
    switch (tier) {
      case NetworkHealthTier.excellent:
        return 'Bandwidth exceeds 10 Mbps with low latency. Ideal for HD streaming & real-time apps.';
      case NetworkHealthTier.fair:
        return 'Bandwidth between 2 - 10 Mbps. Suitable for general browsing and standard video.';
      case NetworkHealthTier.poor:
        return 'Bandwidth below 2 Mbps. May experience buffering and delays.';
      case NetworkHealthTier.degraded:
        return 'No Internet Access — Wi-Fi and Mobile Data are off, or the connection is unreachable. '
            'Please enable a network connection and run the diagnostic again.';
      case NetworkHealthTier.untested:
        return 'Tap "Start Full Diagnostic Test" below to measure idle ping, download, and upload speeds.';
    }
  }

  IconData _getTierIcon(NetworkHealthTier tier) {
    switch (tier) {
      case NetworkHealthTier.excellent:
        return Icons.verified_rounded;
      case NetworkHealthTier.fair:
        return Icons.thumb_up_rounded;
      case NetworkHealthTier.poor:
        return Icons.warning_amber_rounded;
      case NetworkHealthTier.degraded:
        return Icons.portable_wifi_off_rounded;
      case NetworkHealthTier.untested:
        return Icons.network_check_rounded;
    }
  }
}
