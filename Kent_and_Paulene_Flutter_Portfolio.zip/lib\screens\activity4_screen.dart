import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state_provider.dart';
import '../services/mesh_chat_service.dart';

/// Lab 4: Local Mesh Chat Screen
/// Demonstrates P2P local discovery, Bluetooth/Wi-Fi presence advertising,
/// pairing handshake protocol, and declarative text payload routing across a local mesh.
class Activity4Screen extends StatefulWidget {
  const Activity4Screen({super.key});

  @override
  State<Activity4Screen> createState() => _Activity4ScreenState();
}

class _Activity4ScreenState extends State<Activity4Screen> {
  late final MeshChatService _meshService;
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _showPeerPanel = true;
  bool _filterLab4Only = true;

  @override
  void initState() {
    super.initState();
    _meshService = MeshChatService();
    _meshService.addListener(_onMeshUpdate);
  }

  void _onMeshUpdate() {
    if (mounted) {
      setState(() {});
      _scrollToBottom();
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _sendMessage() {
    final text = _textController.text.trim();
    if (text.isEmpty) return;
    _meshService.sendMeshMessage(text);
    _textController.clear();
  }

  @override
  void dispose() {
    _meshService.removeListener(_onMeshUpdate);
    _meshService.dispose();
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final appState = Provider.of<AppStateProvider>(context);
    final isCompleted = appState.isActivityCompleted('lab4');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Lab 4: Local Mesh Chat'),
        actions: [
          IconButton(
            icon: Icon(
              isCompleted ? Icons.check_circle : Icons.check_circle_outline,
              color: isCompleted ? Colors.green : null,
            ),
            tooltip: isCompleted ? 'Completed' : 'Mark as Complete',
            onPressed: () {
              appState.toggleActivityCompletion('lab4');
            },
          ),
          IconButton(
            icon: const Icon(Icons.cleaning_services_rounded),
            tooltip: 'Clear Chat Messages',
            onPressed: () {
              _meshService.clearChat();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Mesh Chat Log Cleared'),
                  duration: Duration(seconds: 1),
                ),
              );
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // 1. Topology & Discovery Header Card
            _buildTopologyHeaderCard(theme),

            // 2. Peer Discovery & Handshake Collapsible Panel
            if (_showPeerPanel) _buildPeerDiscoveryPanel(theme),

            // 3. Declarative Chat Messages Stream (UI = f(state))
            Expanded(
              child: _meshService.chatMessages.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.forum_outlined, size: 64, color: theme.disabledColor),
                          const SizedBox(height: 12),
                          Text(
                            'No P2P mesh messages yet.',
                            style: TextStyle(color: theme.disabledColor),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      physics: const BouncingScrollPhysics(),
                      itemCount: _meshService.chatMessages.length,
                      itemBuilder: (context, index) {
                        final msg = _meshService.chatMessages[index];
                        return _buildMessageBubble(theme, msg);
                      },
                    ),
            ),

            // 4. Input Text Controller Bar
            _buildInputBar(theme),
          ],
        ),
      ),
    );
  }

  Widget _buildTopologyHeaderCard(ThemeData theme) {
    return Container(
      margin: const EdgeInsets.all(12.0),
      padding: const EdgeInsets.all(14.0),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.6),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: theme.colorScheme.outlineVariant.withValues(alpha: 0.4),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: theme.colorScheme.primary.withValues(alpha: 0.15),
                child: Icon(Icons.hub_rounded, color: theme.colorScheme.primary, size: 20),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _meshService.localDeviceName,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                    Text(
                      'ID: ${_meshService.localNodeId} • Nodes: ${_meshService.totalActiveMeshNodes}',
                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: Icon(
                  _showPeerPanel ? Icons.keyboard_arrow_up_rounded : Icons.keyboard_arrow_down_rounded,
                ),
                tooltip: _showPeerPanel ? 'Hide Peers Panel' : 'Show Peers Panel',
                onPressed: () => setState(() => _showPeerPanel = !_showPeerPanel),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Advertising Switch
              FilterChip(
                avatar: Icon(
                  _meshService.isAdvertising ? Icons.sensors_rounded : Icons.sensors_off_rounded,
                  size: 16,
                  color: _meshService.isAdvertising ? Colors.green : Colors.grey,
                ),
                label: Text(
                  _meshService.isAdvertising ? 'Advertising ON' : 'Advertising OFF',
                  style: const TextStyle(fontSize: 11),
                ),
                selected: _meshService.isAdvertising,
                selectedColor: Colors.green.withValues(alpha: 0.2),
                onSelected: (_) => _meshService.toggleAdvertising(),
              ),

              // Discovery Switch
              FilterChip(
                avatar: Icon(
                  _meshService.isDiscovering ? Icons.radar_rounded : Icons.radar,
                  size: 16,
                  color: _meshService.isDiscovering ? Colors.blue : Colors.grey,
                ),
                label: Text(
                  _meshService.isDiscovering ? 'Scanning ON' : 'Scan Nearby',
                  style: const TextStyle(fontSize: 11),
                ),
                selected: _meshService.isDiscovering,
                selectedColor: Colors.blue.withValues(alpha: 0.2),
                onSelected: (_) => _meshService.toggleDiscovery(),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPeerDiscoveryPanel(ThemeData theme) {
    final filteredPeers = _filterLab4Only
        ? _meshService.discoveredPeers
            .where((p) =>
                p.name.contains('Lab 4') ||
                p.deviceType.contains('Mobile') ||
                !p.isBluetooth)
            .toList()
        : _meshService.discoveredPeers;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12.0),
      padding: const EdgeInsets.all(12.0),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Active Connected Peers Row
          Row(
            children: [
              const Icon(Icons.bluetooth_connected_rounded, size: 16, color: Colors.teal),
              const SizedBox(width: 6),
              Text(
                'Connected Mesh Sockets (${_meshService.connectedPeers.length})',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 6),

          if (_meshService.connectedPeers.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 4.0),
              child: Text(
                'No connected peers. Turn on Scanning to discover nearby nodes.',
                style: TextStyle(fontSize: 11, color: Colors.grey),
              ),
            )
          else
            Wrap(
              spacing: 6,
              children: _meshService.connectedPeers.map((peer) {
                return Chip(
                  avatar: const CircleAvatar(
                    backgroundColor: Colors.teal,
                    radius: 8,
                    child: Icon(Icons.check, size: 10, color: Colors.white),
                  ),
                  label: Text(peer.name, style: const TextStyle(fontSize: 11)),
                  onDeleted: () => _meshService.disconnectPeer(peer.id),
                  deleteIconColor: Colors.redAccent,
                );
              }).toList(),
            ),

          const Divider(height: 16),

          // Discovered Nearby Nodes Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.podcasts_rounded, size: 16, color: Colors.blueAccent),
                  const SizedBox(width: 6),
                  Text(
                    'Discovered Nodes (${filteredPeers.length})',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                  ),
                ],
              ),
              Row(
                children: [
                  ChoiceChip(
                    label: Text(
                      _filterLab4Only ? 'Lab 4 Only' : 'All (${_meshService.discoveredPeers.length})',
                      style: const TextStyle(fontSize: 10),
                    ),
                    selected: _filterLab4Only,
                    onSelected: (val) => setState(() => _filterLab4Only = val),
                    visualDensity: VisualDensity.compact,
                  ),
                  const SizedBox(width: 6),
                  if (_meshService.isDiscovering)
                    const SizedBox(
                      width: 14,
                      height: 14,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 8),

          if (filteredPeers.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 4.0),
              child: Text(
                'Scanning for Bluetooth / Wi-Fi subnet nodes...',
                style: TextStyle(fontSize: 11, color: Colors.grey),
              ),
            )
          else
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 130),
              child: ListView.builder(
                shrinkWrap: true,
                physics: const BouncingScrollPhysics(),
                itemCount: filteredPeers.length,
                itemBuilder: (context, index) {
                  final peer = filteredPeers[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 6.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Row(
                            children: [
                              Icon(
                                peer.isBluetooth
                                    ? Icons.bluetooth_searching_rounded
                                    : (peer.deviceType == 'Mobile' ? Icons.phone_android : Icons.computer),
                                size: 16,
                                color: peer.isBluetooth ? Colors.blueAccent : Colors.grey,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      peer.name,
                                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    Text(
                                      peer.signalQuality,
                                      style: const TextStyle(fontSize: 10, color: Colors.grey),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        ElevatedButton(
                          onPressed: peer.connectionState == PeerConnectionState.pairingRequested
                              ? null
                              : () => _meshService.requestPairing(peer),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            minimumSize: Size.zero,
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                          child: Text(
                            peer.connectionState == PeerConnectionState.pairingRequested
                                ? 'Pairing...'
                                : 'Connect / Pair',
                            style: const TextStyle(fontSize: 11),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(ThemeData theme, MeshMessage msg) {
    if (msg.senderId == 'system') {
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.info_outline_rounded, size: 14, color: Colors.grey),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                msg.content,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 11, color: Colors.grey),
              ),
            ),
          ],
        ),
      );
    }

    final formattedTime =
        '${msg.timestamp.hour.toString().padLeft(2, '0')}:${msg.timestamp.minute.toString().padLeft(2, '0')}';

    return Align(
      alignment: msg.isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: msg.isMe
              ? theme.colorScheme.primary
              : theme.colorScheme.secondaryContainer,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(msg.isMe ? 16 : 4),
            bottomRight: Radius.circular(msg.isMe ? 4 : 16),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  msg.senderName,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: msg.isMe ? Colors.white70 : theme.colorScheme.onSecondaryContainer.withValues(alpha: 0.7),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    '⚡ ${msg.hops} Hop',
                    style: TextStyle(
                      fontSize: 9,
                      color: msg.isMe ? Colors.white : theme.colorScheme.onSecondaryContainer,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              msg.content,
              style: TextStyle(
                fontSize: 14,
                color: msg.isMe ? Colors.white : theme.colorScheme.onSecondaryContainer,
              ),
            ),
            const SizedBox(height: 2),
            Align(
              alignment: Alignment.bottomRight,
              child: Text(
                formattedTime,
                style: TextStyle(
                  fontSize: 9,
                  color: msg.isMe ? Colors.white60 : Colors.grey,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputBar(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(top: BorderSide(color: theme.colorScheme.outlineVariant.withValues(alpha: 0.4))),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _textController,
              decoration: InputDecoration(
                hintText: 'Type text payload across P2P mesh...',
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
              ),
              onSubmitted: (_) => _sendMessage(),
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filled(
            onPressed: _sendMessage,
            icon: const Icon(Icons.send_rounded),
            style: IconButton.styleFrom(
              backgroundColor: theme.colorScheme.primary,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
