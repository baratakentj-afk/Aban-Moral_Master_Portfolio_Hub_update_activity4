import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter_ble_peripheral/flutter_ble_peripheral.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

/// Connection state of a discovered peer node in the local mesh network
enum PeerConnectionState {
  discovered,
  pairingRequested,
  pairingIncoming,
  connected,
  disconnected,
}

/// Model representing a peer node in the local mesh network
class PeerNode {
  final String id;
  final String name;
  final String deviceType; // 'Mobile', 'Desktop', 'Tablet', 'Bluetooth BLE'
  final int signalStrength; // RSSI dBm e.g. -45 dBm
  PeerConnectionState connectionState;
  final DateTime firstDiscovered;
  final String? ipAddress;
  final int? port;
  final bool isReal;
  final bool isBluetooth;
  BluetoothDevice? bluetoothDevice;
  BluetoothCharacteristic? gattWriteCharacteristic;
  Socket? socket;

  PeerNode({
    required this.id,
    required this.name,
    required this.deviceType,
    required this.signalStrength,
    this.connectionState = PeerConnectionState.discovered,
    DateTime? firstDiscovered,
    this.ipAddress,
    this.port,
    this.isReal = false,
    this.isBluetooth = false,
    this.bluetoothDevice,
    this.gattWriteCharacteristic,
    this.socket,
  }) : firstDiscovered = firstDiscovered ?? DateTime.now();

  String get signalQuality {
    if (isBluetooth) return 'Real Bluetooth BLE ($signalStrength dBm)';
    if (isReal) return 'Real Wi-Fi P2P ($ipAddress)';
    if (signalStrength >= -50) return 'Excellent Signal ($signalStrength dBm)';
    if (signalStrength >= -70) return 'Good Signal ($signalStrength dBm)';
    if (signalStrength >= -85) return 'Fair Signal ($signalStrength dBm)';
    return 'Weak Signal ($signalStrength dBm)';
  }
}

/// Model representing a text payload routed across the local P2P mesh
class MeshMessage {
  final String id;
  final String senderId;
  final String senderName;
  final String content;
  final DateTime timestamp;
  final bool isMe;
  final int hops; // Number of P2P mesh relay hops
  final String? targetPeerId; // null = broadcast to all mesh peers

  MeshMessage({
    required this.id,
    required this.senderId,
    required this.senderName,
    required this.content,
    required this.timestamp,
    required this.isMe,
    this.hops = 1,
    this.targetPeerId,
  });
}

/// Service managing local P2P device discovery, pairing handshake,
/// and declarative payload routing across the peer-to-peer mesh.
/// Combines Real Wi-Fi UDP/TCP Socket P2P Networking with Demo Mesh Nodes.
class MeshChatService extends ChangeNotifier {
  // Local Node Identity
  late final String _localNodeId;
  late final String _localDeviceName;

  bool _isAdvertising = false;
  bool _isDiscovering = false;

  final List<PeerNode> _discoveredPeers = [];
  final List<PeerNode> _connectedPeers = [];
  final List<MeshMessage> _chatMessages = [];

  Timer? _discoveryTimer;
  Timer? _advertisingTimer;
  Timer? _simulationTimer;

  // Real Socket Properties (Platform safe)
  RawDatagramSocket? _udpSocket;
  ServerSocket? _tcpServer;
  int _tcpPort = 8889;
  static const int _udpPort = 8888;

  // Resolved subnet broadcast addresses (e.g. 192.168.1.255)
  // Android blocks 255.255.255.255 on most networks
  final List<String> _broadcastAddresses = [];
  bool _socketsReady = false;

  // Handshake callback for UI verification prompts
  PeerNode? _pendingIncomingPairing;

  MeshChatService() {
    final random = Random();
    _localNodeId = 'node_${random.nextInt(0xFFFFFF).toRadixString(16).padLeft(6, '0')}';
    _localDeviceName = 'Kent & Paulene Node (${_localNodeId.substring(5)})';

    // Pre-seed the 3 named demo nodes immediately (always visible)
    _discoveredPeers.addAll([
      PeerNode(
        id: 'node_alpha',
        name: "Paulene's Galaxy S24",
        deviceType: 'Mobile',
        signalStrength: -47,
      ),
      PeerNode(
        id: 'node_beta',
        name: "Kent's Laptop Pro",
        deviceType: 'Desktop',
        signalStrength: -61,
      ),
      PeerNode(
        id: 'node_gamma',
        name: "CS416 Lab Peer Router",
        deviceType: 'Tablet',
        signalStrength: -68,
      ),
    ]);

    // Seed default welcome message in mesh state
    _chatMessages.add(
      MeshMessage(
        id: 'msg_init',
        senderId: 'system',
        senderName: 'Mesh Network System',
        content: 'Local P2P Mesh Network Initialized — 3 demo nodes pre-loaded. Real Wi-Fi sockets also active.',
        timestamp: DateTime.now(),
        isMe: false,
        hops: 0,
      ),
    );

    // Initialize real socket & GATT listeners on supported platforms
    if (!kIsWeb) {
      _initRealSockets();
      _initBleGattListener();
    }
  }

  StreamSubscription<Uint8List>? _bleGattDataSub;

  /// Safely add incoming mesh message with deduplication and self-echo suppression
  void _addIncomingMessage(MeshMessage msg) {
    // 1. Ignore messages sent by ourselves (e.g. broadcast loopback / echo)
    if (msg.senderId == _localNodeId) return;

    // 2. Prevent duplicate messages with the same message ID
    if (_chatMessages.any((m) => m.id == msg.id)) {
      debugPrint('[MeshChat] Ignored duplicate message ID: ${msg.id}');
      return;
    }

    _chatMessages.add(msg);
    notifyListeners();
  }

  void _initBleGattListener() {
    _bleGattDataSub?.cancel();
    _bleGattDataSub = _blePeripheral.onDataReceived.listen((data) {
      try {
        final payload = utf8.decode(data);
        final json = jsonDecode(payload) as Map<String, dynamic>;
        if (json['type'] == 'msg') {
          final msgId = json['id'] ?? 'msg_${json['content']}_${json['senderId']}';
          _addIncomingMessage(
            MeshMessage(
              id: msgId,
              senderId: json['senderId'] ?? 'ble_peer',
              senderName: json['senderName'] ?? 'Bluetooth Peer',
              content: json['content'] ?? '',
              timestamp: DateTime.now(),
              isMe: false,
              hops: (json['hops'] as int? ?? 1),
            ),
          );
        }
      } catch (e) {
        debugPrint('[MeshChat] Error decoding BLE GATT message: $e');
      }
    });
  }

  // Getters
  String get localNodeId => _localNodeId;
  String get localDeviceName => _localDeviceName;
  bool get isAdvertising => _isAdvertising;
  bool get isDiscovering => _isDiscovering;
  bool get isBleScanning => _isBleScanning;
  List<PeerNode> get discoveredPeers => List.unmodifiable(_discoveredPeers);
  List<PeerNode> get connectedPeers => List.unmodifiable(_connectedPeers);
  List<MeshMessage> get chatMessages => List.unmodifiable(_chatMessages);
  PeerNode? get pendingIncomingPairing => _pendingIncomingPairing;

  int get totalActiveMeshNodes => _connectedPeers.length + 1; // connected peers + local node

  // -----------------------------------------------------------------
  // REAL SOCKET P2P INITIALIZATION (Wi-Fi UDP & TCP)
  // -----------------------------------------------------------------

  /// Compute subnet broadcast addresses from all active network interfaces.
  /// e.g. if device IP is 192.168.1.105/24 → broadcast is 192.168.1.255
  Future<void> _resolveSubnetBroadcasts() async {
    _broadcastAddresses.clear();
    try {
      final interfaces = await NetworkInterface.list(
        includeLinkLocal: false,
        type: InternetAddressType.IPv4,
      );
      for (final iface in interfaces) {
        for (final addr in iface.addresses) {
          final parts = addr.address.split('.');
          if (parts.length == 4) {
            // Assume /24 subnet mask — compute x.x.x.255
            final broadcast = '${parts[0]}.${parts[1]}.${parts[2]}.255';
            if (!_broadcastAddresses.contains(broadcast)) {
              _broadcastAddresses.add(broadcast);
            }
          }
        }
      }
    } catch (e) {
      debugPrint('[MeshChat] Subnet resolve error: $e');
    }
    // Always include limited broadcast as fallback
    if (!_broadcastAddresses.contains('255.255.255.255')) {
      _broadcastAddresses.add('255.255.255.255');
    }
    debugPrint('[MeshChat] Broadcast targets: $_broadcastAddresses');
  }

  Future<void> _initRealSockets() async {
    try {
      // Resolve subnet broadcast addresses from active interfaces
      await _resolveSubnetBroadcasts();

      // Bind TCP server for real peer connection sockets
      _tcpServer = await ServerSocket.bind(InternetAddress.anyIPv4, 0);
      _tcpPort = _tcpServer!.port;
      _tcpServer!.listen(_handleIncomingTcpSocket);

      // Bind UDP datagram socket for subnet discovery beacons
      // Use port 0 first attempt, then _udpPort for receive
      _udpSocket = await RawDatagramSocket.bind(
        InternetAddress.anyIPv4,
        _udpPort,
        reuseAddress: true,
        reusePort: false,
      );
      _udpSocket!.broadcastEnabled = true;
      _udpSocket!.listen((event) {
        if (event == RawSocketEvent.read) {
          final dg = _udpSocket!.receive();
          if (dg != null) _handleIncomingUdpBeacon(dg);
        }
      });

      _socketsReady = true;
      debugPrint('[MeshChat] Sockets ready — TCP port: $_tcpPort, UDP port: $_udpPort');
    } catch (e) {
      debugPrint('[MeshChat] Socket init error: $e');
      _socketsReady = false;
    }
  }

  void _handleIncomingUdpBeacon(Datagram dg) {
    try {
      final payload = utf8.decode(dg.data);
      final json = jsonDecode(payload) as Map<String, dynamic>;

      final remoteId = json['id'] as String?;
      final remoteName = json['name'] as String?;
      final remoteTcpPort = json['port'] as int?;

      if (remoteId == null || remoteId == _localNodeId || remoteTcpPort == null) {
        return;
      }

      final senderIp = dg.address.address;
      final peerId = 'real_$remoteId';

      final existingIndex = _discoveredPeers.indexWhere((p) => p.id == peerId);
      final realPeer = PeerNode(
        id: peerId,
        name: '[Real Wi-Fi] ${remoteName ?? "Peer Device"}',
        deviceType: 'Mobile/PC',
        signalStrength: -40,
        ipAddress: senderIp,
        port: remoteTcpPort,
        isReal: true,
      );

      if (existingIndex == -1) {
        if (!_connectedPeers.any((p) => p.id == peerId)) {
          _discoveredPeers.insert(0, realPeer);
          notifyListeners();
        }
      }
    } catch (_) {}
  }

  void _handleIncomingTcpSocket(Socket clientSocket) {
    clientSocket.listen((data) {
      try {
        final payload = utf8.decode(data);
        final json = jsonDecode(payload) as Map<String, dynamic>;

        final type = json['type'] as String?;
        if (type == 'msg') {
          final msgId = json['id'] ?? 'msg_${json['content']}_${json['senderId']}';
          _addIncomingMessage(
            MeshMessage(
              id: msgId,
              senderId: json['senderId'] ?? 'remote',
              senderName: json['senderName'] ?? 'Wi-Fi Peer',
              content: json['content'] ?? '',
              timestamp: DateTime.now(),
              isMe: false,
              hops: (json['hops'] as int? ?? 1),
            ),
          );
        }
      } catch (_) {}
    });
  }

  void _sendUdpBeacon() {
    if (_udpSocket == null || !_isAdvertising || !_socketsReady) return;
    final beacon = jsonEncode({
      'id': _localNodeId,
      'name': _localDeviceName,
      'port': _tcpPort,
      'type': 'beacon',
    });
    final bytes = utf8.encode(beacon);

    // Send to every resolved broadcast address (subnet + limited broadcast)
    for (final addr in _broadcastAddresses) {
      try {
        final sent = _udpSocket!.send(bytes, InternetAddress(addr), _udpPort);
        debugPrint('[MeshChat] Beacon sent to $addr:$_udpPort ($sent bytes)');
      } catch (e) {
        debugPrint('[MeshChat] Beacon send error ($addr): $e');
      }
    }
  }

  // Real Bluetooth BLE Scanning & Advertising Properties
  final FlutterBlePeripheral _blePeripheral = FlutterBlePeripheral();
  static const String _meshServiceUuid = 'bf000000-0000-1000-8000-00805f9b34fb';
  StreamSubscription<List<ScanResult>>? _bleScanSubscription;
  // FIX 1: Track isScanning stream so we can auto-restart when the 15s scan expires
  StreamSubscription<bool>? _isScanningSubscription;
  // FIX 1: Timer used to delay scan restart after it stops
  Timer? _bleScanRestartTimer;
  bool _isBleScanning = false;

  /// Request runtime permissions for Bluetooth BLE and Location
  Future<void> requestBluetoothPermissions() async {
    if (kIsWeb) return;
    try {
      if (Platform.isAndroid) {
        final statusMap = await [
          Permission.bluetoothScan,
          Permission.bluetoothConnect,
          Permission.bluetoothAdvertise,
          Permission.locationWhenInUse,
          Permission.location,
        ].request();
        debugPrint('[MeshChat] Bluetooth permissions requested: $statusMap');
      }
    } catch (e) {
      debugPrint('[MeshChat] Bluetooth permission error: $e');
    }
  }

  /// Start real Bluetooth BLE Advertising (makes this device discoverable over BLE)
  /// FIX 2: Explicitly verify BLUETOOTH_ADVERTISE permission before starting,
  /// confirm advertising actually started, and report failure clearly in the chat.
  Future<void> startBleAdvertising() async {
    if (kIsWeb) return;
    try {
      await requestBluetoothPermissions();

      // FIX 2: Explicitly check BLUETOOTH_ADVERTISE was granted before calling start()
      if (Platform.isAndroid) {
        final advertiseGranted = await Permission.bluetoothAdvertise.isGranted;
        if (!advertiseGranted) {
          debugPrint('[MeshChat] BLUETOOTH_ADVERTISE permission denied — cannot advertise');
          _chatMessages.add(
            MeshMessage(
              id: 'msg_bt_perm_${DateTime.now().millisecondsSinceEpoch}',
              senderId: 'system',
              senderName: 'Bluetooth BLE Advertiser',
              content: 'BLE Advertising failed: Bluetooth permission was denied. Please grant "Nearby Devices" permission in App Settings.',
              timestamp: DateTime.now(),
              isMe: false,
              hops: 0,
            ),
          );
          notifyListeners();
          return;
        }
      }

      final isSupported = await _blePeripheral.isSupported;
      if (!isSupported) {
        debugPrint('[MeshChat] BLE Peripheral Advertising not supported on hardware');
        _chatMessages.add(
          MeshMessage(
            id: 'msg_bt_unsupported_${DateTime.now().millisecondsSinceEpoch}',
            senderId: 'system',
            senderName: 'Bluetooth BLE Advertiser',
            content: 'This device hardware does not support BLE Peripheral Advertising. Use Wi-Fi mode instead.',
            timestamp: DateTime.now(),
            isMe: false,
            hops: 0,
          ),
        );
        notifyListeners();
        return;
      }

      final advertiseData = Platform.isAndroid
          ? AndroidAdvertiseData(
              serviceUuid: _meshServiceUuid,
              includeDeviceName: true,
            )
          : AdvertiseDataCore(
              serviceUuid: _meshServiceUuid,
              localName: _localDeviceName,
            );

      await _blePeripheral.start(
        advertiseData: advertiseData,
        gattServer: const GattServerSettings(),
      );

      // FIX 2: Verify advertising is actually running after start()
      final isNowAdvertising = await _blePeripheral.isAdvertising;
      if (!isNowAdvertising) {
        debugPrint('[MeshChat] BLE start() called but isAdvertising=false — silently failed');
        _chatMessages.add(
          MeshMessage(
            id: 'msg_bt_adv_fail_${DateTime.now().millisecondsSinceEpoch}',
            senderId: 'system',
            senderName: 'Bluetooth BLE Advertiser',
            content: 'BLE Advertising could not start (device may have battery optimization blocking it). Try disabling Battery Saver and retry.',
            timestamp: DateTime.now(),
            isMe: false,
            hops: 0,
          ),
        );
        notifyListeners();
        return;
      }

      debugPrint('[MeshChat] BLE Peripheral Advertising confirmed active as "$_localDeviceName"');
      _chatMessages.add(
        MeshMessage(
          id: 'msg_bt_adv_${DateTime.now().millisecondsSinceEpoch}',
          senderId: 'system',
          senderName: 'Bluetooth BLE Advertiser',
          content: '✅ BLE Advertising active — Phone B can now discover this device. No manual Bluetooth pairing needed.',
          timestamp: DateTime.now(),
          isMe: false,
          hops: 0,
        ),
      );
      notifyListeners();
    } catch (e) {
      debugPrint('[MeshChat] BLE Advertising exception: $e');
      _chatMessages.add(
        MeshMessage(
          id: 'msg_bt_adv_err_${DateTime.now().millisecondsSinceEpoch}',
          senderId: 'system',
          senderName: 'Bluetooth BLE Advertiser',
          content: 'BLE Advertising error: $e',
          timestamp: DateTime.now(),
          isMe: false,
          hops: 0,
        ),
      );
      notifyListeners();
    }
  }

  /// Stop real Bluetooth BLE Advertising
  Future<void> stopBleAdvertising() async {
    if (kIsWeb) return;
    try {
      await _blePeripheral.stop();
      debugPrint('[MeshChat] BLE Peripheral Advertising stopped');
    } catch (e) {
      debugPrint('[MeshChat] BLE stopAdvertising exception: $e');
    }
  }

  /// Start real Bluetooth BLE device discovery scan.
  /// FIX 1: Scan no longer has a 15s timeout — it runs continuously.
  ///         An isScanning listener auto-restarts the scan if it stops.
  /// FIX 4: Adds a message clarifying manual BT pairing is NOT needed.
  Future<void> startBleScan() async {
    if (kIsWeb) return;
    // Prevent duplicate scan starts if already active
    if (await FlutterBluePlus.isScanning.first) {
      debugPrint('[MeshChat] BLE scan already running — skipping duplicate start');
      return;
    }
    try {
      await requestBluetoothPermissions();
      final isSupported = await FlutterBluePlus.isSupported;
      if (!isSupported) {
        debugPrint('[MeshChat] BLE not supported on device');
        return;
      }

      // Check adapter state
      final adapterState = await FlutterBluePlus.adapterState.first;
      if (adapterState != BluetoothAdapterState.on) {
        debugPrint('[MeshChat] Bluetooth is OFF ($adapterState)');
        _chatMessages.add(
          MeshMessage(
            id: 'msg_bt_off_${DateTime.now().millisecondsSinceEpoch}',
            senderId: 'system',
            senderName: 'Bluetooth Scanner',
            content: 'Please turn ON Bluetooth on your device to discover nearby Bluetooth nodes.',
            timestamp: DateTime.now(),
            isMe: false,
            hops: 0,
          ),
        );
        notifyListeners();
        return;
      }

      // FIX 4: Inform user that manual Bluetooth pairing is NOT required for BLE discovery
      if (!_isBleScanning) {
        _chatMessages.add(
          MeshMessage(
            id: 'msg_bt_info_${DateTime.now().millisecondsSinceEpoch}',
            senderId: 'system',
            senderName: 'Bluetooth Scanner',
            content: '🔍 BLE scan started. NOTE: Do NOT manually pair Bluetooth in Settings — BLE discovery is automatic. Just ensure the other phone has Advertising ON.',
            timestamp: DateTime.now(),
            isMe: false,
            hops: 0,
          ),
        );
        notifyListeners();
      }

      _bleScanSubscription?.cancel();
      _bleScanSubscription = FlutterBluePlus.scanResults.listen((results) {
        for (final r in results) {
          final device = r.device;
          String rawName = device.platformName.isNotEmpty
              ? device.platformName
              : (r.advertisementData.advName.isNotEmpty
                  ? r.advertisementData.advName
                  : '');

          // Detect if advertisement has our custom Mesh Service UUID
          final isLab4Peer = r.advertisementData.serviceUuids.any(
            (uuid) => uuid.toString().toLowerCase().contains('bf000000') || uuid.toString().toLowerCase().contains('bf00'),
          );

          final shortId = device.remoteId.str.length > 5
              ? device.remoteId.str.substring(0, 5)
              : device.remoteId.str;

          if (rawName.isEmpty && isLab4Peer) {
            rawName = 'Lab 4 Node ($shortId)';
          }

          final displayName = rawName.isNotEmpty ? rawName : 'BT Device ($shortId)';
          final peerId = 'bt_${device.remoteId.str}';

          final existingIndex = _discoveredPeers.indexWhere((p) => p.id == peerId);
          final btPeer = PeerNode(
            id: peerId,
            name: isLab4Peer ? '[Lab 4 BLE] $displayName' : '[Bluetooth] $displayName',
            deviceType: isLab4Peer ? 'Lab 4 Peer Mobile' : 'Bluetooth BLE',
            signalStrength: r.rssi,
            isReal: true,
            isBluetooth: true,
            bluetoothDevice: device,
          );

          if (existingIndex == -1) {
            if (!_connectedPeers.any((p) => p.id == peerId)) {
              if (isLab4Peer) {
                _discoveredPeers.insert(0, btPeer);
              } else {
                _discoveredPeers.add(btPeer);
              }
              notifyListeners();
            }
          } else {
            _discoveredPeers[existingIndex] = btPeer;
            notifyListeners();
          }
        }
      });

      // FIX 1: No timeout — scan runs until explicitly stopped.
      // We listen to isScanning and auto-restart when it stops (e.g. OS kills it).
      _isScanningSubscription?.cancel();
      _isScanningSubscription = FlutterBluePlus.isScanning.listen((scanning) {
        if (!scanning && (_isDiscovering || _isAdvertising)) {
          // Scan stopped but we still want it running — restart after short delay
          _bleScanRestartTimer?.cancel();
          _bleScanRestartTimer = Timer(const Duration(seconds: 3), () {
            if (_isDiscovering || _isAdvertising) {
              debugPrint('[MeshChat] BLE scan expired — auto-restarting...');
              startBleScan();
            }
          });
        }
      });

      // FIX 1: No timeout parameter — runs continuously
      await FlutterBluePlus.startScan(
        androidScanMode: AndroidScanMode.lowLatency,
        androidUsesFineLocation: false,
      );
      _isBleScanning = true;
      debugPrint('[MeshChat] BLE scan started (continuous — no timeout)');
    } catch (e) {
      debugPrint('[MeshChat] BLE startScan exception: $e');
    }
  }

  /// Stop real Bluetooth BLE scan
  Future<void> stopBleScan() async {
    if (kIsWeb) return;
    // FIX 1: Cancel restart machinery before stopping
    _bleScanRestartTimer?.cancel();
    _isScanningSubscription?.cancel();
    try {
      await FlutterBluePlus.stopScan();
      _bleScanSubscription?.cancel();
      _isBleScanning = false;
      debugPrint('[MeshChat] BLE scan stopped');
    } catch (e) {
      debugPrint('[MeshChat] BLE stopScan exception: $e');
    }
  }

  // -----------------------------------------------------------------
  // LOCAL DISCOVERY & ADVERTISING
  // -----------------------------------------------------------------

  /// Start broadcasting local node presence
  void startAdvertising() {
    _isAdvertising = true;
    startBleAdvertising();
    startBleScan();

    _advertisingTimer?.cancel();
    _advertisingTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (_isAdvertising) {
        _sendUdpBeacon();
      }
    });

    notifyListeners();
  }

  /// Stop broadcasting local node presence
  void stopAdvertising() {
    _isAdvertising = false;
    _advertisingTimer?.cancel();
    stopBleAdvertising();
    if (!_isDiscovering) stopBleScan();
    notifyListeners();
  }

  void toggleAdvertising() {
    if (_isAdvertising) {
      stopAdvertising();
    } else {
      startAdvertising();
    }
  }

  /// Start actively scanning for neighboring P2P nodes
  void startDiscovery() {
    if (_isDiscovering) return;
    _isDiscovering = true;
    startBleScan();
    notifyListeners();

    // Trigger initial scan burst
    _scanNearbyEnvironment();

    // Periodic discovery refresh timer
    _discoveryTimer?.cancel();
    _discoveryTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (_isDiscovering) {
        _scanNearbyEnvironment();
      }
    });
  }

  /// Stop scanning for neighboring nodes
  void stopDiscovery() {
    _isDiscovering = false;
    _discoveryTimer?.cancel();
    if (!_isAdvertising) stopBleScan();
    notifyListeners();
  }

  void toggleDiscovery() {
    if (_isDiscovering) {
      stopDiscovery();
    } else {
      startDiscovery();
    }
  }

  /// Refreshes signal strength of pre-seeded demo nodes and sends a UDP
  /// beacon to discover real Wi-Fi peers on the local subnet.
  void _scanNearbyEnvironment() {
    final random = Random();

    // Refresh signal quality of the 3 pre-seeded demo nodes (simulate fluctuation)
    final demoIds = ['node_alpha', 'node_beta', 'node_gamma'];
    final demoSignals = {
      'node_alpha': -45 - random.nextInt(15),
      'node_beta': -58 - random.nextInt(20),
      'node_gamma': -65 - random.nextInt(15),
    };
    final demoTypes = {
      'node_alpha': 'Mobile',
      'node_beta': 'Desktop',
      'node_gamma': 'Tablet',
    };
    final demoNames = {
      'node_alpha': "Paulene's Galaxy S24",
      'node_beta': "Kent's Laptop Pro",
      'node_gamma': "CS416 Lab Peer Router",
    };

    for (final id in demoIds) {
      final existingIndex = _discoveredPeers.indexWhere((p) => p.id == id);
      if (existingIndex != -1 && !_discoveredPeers[existingIndex].isReal) {
        // Refresh with updated signal strength to simulate live scanning
        final prev = _discoveredPeers[existingIndex];
        _discoveredPeers[existingIndex] = PeerNode(
          id: id,
          name: demoNames[id]!,
          deviceType: demoTypes[id]!,
          signalStrength: demoSignals[id]!,
          connectionState: prev.connectionState,
          firstDiscovered: prev.firstDiscovered,
        );
      } else if (existingIndex == -1 &&
          !_connectedPeers.any((p) => p.id == id)) {
        // Re-add if somehow removed (e.g., after disconnect)
        _discoveredPeers.add(PeerNode(
          id: id,
          name: demoNames[id]!,
          deviceType: demoTypes[id]!,
          signalStrength: demoSignals[id]!,
        ));
      }
    }

    // Also send a real UDP beacon so actual local subnet devices are discovered
    _sendUdpBeacon();

    notifyListeners();
  }

  // -----------------------------------------------------------------
  // CONNECTION & HANDSHAKE PROTOCOL
  // -----------------------------------------------------------------

  /// Request pairing handshake with a discovered node
  Future<void> requestPairing(PeerNode peer) async {
    final index = _discoveredPeers.indexWhere((p) => p.id == peer.id);
    if (index != -1) {
      _discoveredPeers[index].connectionState = PeerConnectionState.pairingRequested;
      notifyListeners();
    }

    // Real Wi-Fi peer TCP socket pairing logic
    if (peer.isReal && peer.ipAddress != null && peer.port != null) {
      try {
        final socket = await Socket.connect(peer.ipAddress!, peer.port!);
        peer.socket = socket;
        _handleIncomingTcpSocket(socket);
      } catch (e) {
        debugPrint('TCP connection error: $e');
      }
    } else if (peer.isBluetooth && peer.bluetoothDevice != null) {
      try {
        final dev = peer.bluetoothDevice!;
        debugPrint('[MeshChat] Connecting to BLE GATT peer: ${dev.remoteId}');
        await dev.connect(timeout: const Duration(seconds: 8));
        final services = await dev.discoverServices();
        for (final s in services) {
          for (final c in s.characteristics) {
            if (c.properties.write || c.properties.writeWithoutResponse) {
              peer.gattWriteCharacteristic = c;
            }
            if (c.properties.notify || c.properties.indicate) {
              await c.setNotifyValue(true);
              c.lastValueStream.listen((data) {
                try {
                  final payload = utf8.decode(data);
                  final json = jsonDecode(payload) as Map<String, dynamic>;
                  if (json['type'] == 'msg') {
                    final msgId = json['id'] ?? 'msg_${json['content']}_${json['senderId']}';
                    _addIncomingMessage(
                      MeshMessage(
                        id: msgId,
                        senderId: json['senderId'] ?? 'ble_peer',
                        senderName: json['senderName'] ?? peer.name,
                        content: json['content'] ?? '',
                        timestamp: DateTime.now(),
                        isMe: false,
                        hops: 1,
                      ),
                    );
                  }
                } catch (_) {}
              });
            }
          }
        }
        debugPrint('[MeshChat] BLE GATT session ready with ${dev.platformName}');
      } catch (e) {
        debugPrint('[MeshChat] BLE GATT connection error: $e');
      }
    } else {
      // Simulate handshake roundtrip delay for demo nodes
      await Future.delayed(const Duration(milliseconds: 1200));
    }

    // Establish connection socket
    if (index != -1 && _discoveredPeers.contains(_discoveredPeers[index])) {
      final target = _discoveredPeers.removeAt(index);
      target.connectionState = PeerConnectionState.connected;
      _connectedPeers.add(target);

      // System notification payload
      _chatMessages.add(
        MeshMessage(
          id: 'msg_handshake_${DateTime.now().millisecondsSinceEpoch}',
          senderId: 'system',
          senderName: 'Handshake Protocol',
          content: 'Established P2P mesh socket session with "${target.name}".',
          timestamp: DateTime.now(),
          isMe: false,
          hops: 1,
        ),
      );

      notifyListeners();
    }
  }

  /// Accept incoming pairing handshake from a peer
  void acceptIncomingPairing() {
    if (_pendingIncomingPairing != null) {
      final peer = _pendingIncomingPairing!;
      peer.connectionState = PeerConnectionState.connected;
      _connectedPeers.add(peer);
      _pendingIncomingPairing = null;

      _chatMessages.add(
        MeshMessage(
          id: 'msg_accept_${DateTime.now().millisecondsSinceEpoch}',
          senderId: 'system',
          senderName: 'Handshake Protocol',
          content: 'Accepted pairing request from "${peer.name}". Mesh socket ready.',
          timestamp: DateTime.now(),
          isMe: false,
          hops: 1,
        ),
      );

      notifyListeners();
    }
  }

  /// Reject incoming pairing handshake
  void rejectIncomingPairing() {
    _pendingIncomingPairing = null;
    notifyListeners();
  }

  /// Disconnect a connected peer socket session
  void disconnectPeer(String peerId) {
    final index = _connectedPeers.indexWhere((p) => p.id == peerId);
    if (index != -1) {
      final removed = _connectedPeers.removeAt(index);
      removed.connectionState = PeerConnectionState.disconnected;
      try {
        removed.socket?.close();
      } catch (_) {}

      _chatMessages.add(
        MeshMessage(
          id: 'msg_disc_${DateTime.now().millisecondsSinceEpoch}',
          senderId: 'system',
          senderName: 'Handshake Protocol',
          content: 'Closed P2P socket connection with "${removed.name}".',
          timestamp: DateTime.now(),
          isMe: false,
          hops: 0,
        ),
      );

      notifyListeners();
    }
  }

  // -----------------------------------------------------------------
  // PAYLOAD ROUTING & MESSAGING
  // -----------------------------------------------------------------

  /// Route text payload across established peer-to-peer mesh
  void sendMeshMessage(String text, {String? targetPeerId}) {
    if (text.trim().isEmpty) return;

    final msgId = 'msg_${DateTime.now().millisecondsSinceEpoch}';
    final newMessage = MeshMessage(
      id: msgId,
      senderId: _localNodeId,
      senderName: _localDeviceName,
      content: text.trim(),
      timestamp: DateTime.now(),
      isMe: true,
      hops: 1,
      targetPeerId: targetPeerId,
    );

    _chatMessages.add(newMessage);
    notifyListeners();

    // Send payload over real TCP socket streams if real peers connected
    final payloadJson = jsonEncode({
      'type': 'msg',
      'id': msgId,
      'senderId': _localNodeId,
      'senderName': _localDeviceName,
      'content': text.trim(),
      'hops': 1,
    });

    for (final peer in _connectedPeers) {
      if (peer.isReal && peer.socket != null) {
        try {
          peer.socket!.write(payloadJson);
        } catch (_) {}
      }
    }

    // Broadcast over UDP mesh channel for local mesh connectivity
    final bytes = utf8.encode(payloadJson);
    if (_udpSocket != null && _socketsReady) {
      for (final addr in _broadcastAddresses) {
        try {
          _udpSocket!.send(bytes, InternetAddress(addr), _udpPort);
        } catch (_) {}
      }
    }

    // Send over real Bluetooth BLE GATT channels
    if (_isAdvertising) {
      try {
        _blePeripheral.sendData(bytes);
      } catch (e) {
        debugPrint('[MeshChat] BLE sendData error: $e');
      }
    }

    for (final peer in _connectedPeers) {
      if (peer.isBluetooth && peer.gattWriteCharacteristic != null) {
        try {
          peer.gattWriteCharacteristic!.write(bytes, withoutResponse: true);
        } catch (e) {
          debugPrint('[MeshChat] BLE GATT write error: $e');
        }
      }
    }

    // Simulate P2P echo response from demo nodes if connected
    if (_connectedPeers.any((p) => !p.isReal)) {
      _simulatePeerResponse(text);
    }
  }

  void _simulatePeerResponse(String userPrompt) {
    _simulationTimer?.cancel();
    _simulationTimer = Timer(const Duration(milliseconds: 1800), () {
      final demoPeer = _connectedPeers.firstWhere(
        (p) => !p.isReal,
        orElse: () => _connectedPeers.first,
      );
      final random = Random();
      final hops = 1 + random.nextInt(2);

      final responses = [
        'Received payload via P2P mesh socket: "$userPrompt"',
        'Packet delivered successfully across local Wi-Fi/Bluetooth subnet!',
        'Mesh node "${demoPeer.name}" confirmed handshake payload routing.',
      ];

      _chatMessages.add(
        MeshMessage(
          id: 'msg_resp_${DateTime.now().millisecondsSinceEpoch}',
          senderId: demoPeer.id,
          senderName: demoPeer.name,
          content: responses[random.nextInt(responses.length)],
          timestamp: DateTime.now(),
          isMe: false,
          hops: hops,
        ),
      );

      notifyListeners();
    });
  }

  void clearChat() {
    _chatMessages.clear();
    notifyListeners();
  }

  @override
  void dispose() {
    _discoveryTimer?.cancel();
    _advertisingTimer?.cancel();
    _simulationTimer?.cancel();
    // FIX 1: Cancel scan restart timer and isScanning subscription
    _bleScanRestartTimer?.cancel();
    _isScanningSubscription?.cancel();
    _bleGattDataSub?.cancel();
    stopBleScan();
    stopBleAdvertising();
    try {
      _udpSocket?.close();
      _tcpServer?.close();
    } catch (_) {}
    super.dispose();
  }
}
